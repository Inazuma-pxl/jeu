export interface Attack {
  damage: number;
  range: number;
  cooldown: number;
  lastUsed?: number;
}

export interface Direction {
  facing: 'up' | 'down' | 'left' | 'right';
}

export interface CombatStats {
  isAttacking: boolean;
  attackCooldown: number;
  lastAttackTime: number;
}