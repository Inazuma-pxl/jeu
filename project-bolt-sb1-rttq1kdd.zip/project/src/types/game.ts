export interface Player {
  level: number;
  exp: number;
  maxExp: number;
  health: number;
  maxHealth: number;
  attack: number;
  defense: number;
  position: { x: number; y: number };
  direction: 'up' | 'down' | 'left' | 'right';
  isAttacking: boolean;
  lastAttackTime: number;
  stats: PlayerStats;
  abilities: Ability[];
}

export interface Enemy {
  id: string;
  type: 'monster' | 'boss';
  name: string;
  health: number;
  maxHealth: number;
  attack: number;
  position: { x: number; y: number };
  sprite: string;
  isStunned: boolean;
  expValue: number;
}

export interface GameState {
  player: Player;
  enemies: Enemy[];
  gameMap: number[][];
  gameStatus: 'playing' | 'paused' | 'gameOver';
  showLevelUp: boolean;
  lastLevelUpRewards?: LevelUpRewards;
}