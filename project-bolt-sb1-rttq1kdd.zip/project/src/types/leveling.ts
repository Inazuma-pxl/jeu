export interface SkillPoints {
  strength: number;
  agility: number;
  vitality: number;
  intelligence: number;
}

export interface PlayerStats extends SkillPoints {
  availablePoints: number;
  criticalChance: number;
  criticalDamage: number;
  dodgeChance: number;
  magicResistance: number;
}

export interface LevelUpRewards {
  skillPoints: number;
  healthBonus: number;
  attackBonus: number;
  defenseBonus: number;
  newAbilityUnlocked?: string;
}

export interface Ability {
  id: string;
  name: string;
  description: string;
  damage: number;
  cooldown: number;
  requiredLevel: number;
  manaCost: number;
  unlocked: boolean;
}