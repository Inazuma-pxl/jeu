import { useState, useEffect, useCallback } from 'react';
import { GameState, Player, Enemy } from '../types/game';
import { isInRange, calculateDamage, canAttack } from '../utils/combat';
import { calculateExpToNextLevel, calculateLevelUpRewards, applySkillPoint } from '../utils/leveling';
import { calculateNewPosition, isValidPosition } from '../utils/movement';
import { spawnEnemy } from '../utils/enemies';
import { SkillPoints } from '../types/leveling';

const INITIAL_PLAYER: Player = {
  level: 1,
  exp: 0,
  maxExp: calculateExpToNextLevel(1),
  health: 100,
  maxHealth: 100,
  attack: 10,
  defense: 5,
  position: { x: window.innerWidth / 2, y: window.innerHeight / 2 },
  direction: 'down',
  isAttacking: false,
  lastAttackTime: 0,
  stats: {
    strength: 5,
    agility: 5,
    vitality: 5,
    intelligence: 5,
    availablePoints: 0,
    criticalChance: 5,
    criticalDamage: 150,
    dodgeChance: 1.5,
    magicResistance: 2.5
  },
  abilities: []
};

const INITIAL_STATE: GameState = {
  player: INITIAL_PLAYER,
  enemies: [],
  gameMap: [],
  gameStatus: 'playing',
  showLevelUp: false
};

export const useGame = () => {
  const [gameState, setGameState] = useState<GameState>(INITIAL_STATE);

  const movePlayer = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    setGameState(prev => {
      const newPosition = calculateNewPosition(prev.player.position, direction);
      
      if (!isValidPosition(newPosition, { width: window.innerWidth, height: window.innerHeight })) {
        return prev;
      }

      return {
        ...prev,
        player: {
          ...prev.player,
          position: newPosition,
          direction
        }
      };
    });
  }, []);

  const attackEnemy = useCallback(() => {
    setGameState(prev => {
      if (!canAttack(prev.player)) return prev;

      const now = Date.now();
      let expGained = 0;

      const updatedEnemies = prev.enemies.map(enemy => {
        if (!isInRange(prev.player, enemy, 50)) return enemy;

        const damage = calculateDamage(prev.player, enemy);
        const newHealth = enemy.health - damage;

        if (newHealth <= 0) {
          expGained += enemy.expValue;
          return null;
        }

        return {
          ...enemy,
          health: newHealth
        };
      }).filter(Boolean) as Enemy[];

      const updatedPlayer = {
        ...prev.player,
        isAttacking: true,
        lastAttackTime: now,
        exp: prev.player.exp + expGained
      };

      // Reset attack state after animation
      setTimeout(() => {
        setGameState(current => ({
          ...current,
          player: {
            ...current.player,
            isAttacking: false
          }
        }));
      }, 200);

      return {
        ...prev,
        player: updatedPlayer,
        enemies: updatedEnemies
      };
    });
  }, []);

  const handleLevelUp = useCallback((player: Player) => {
    const rewards = calculateLevelUpRewards(player.level);
    const updatedPlayer = {
      ...player,
      maxHealth: player.maxHealth + rewards.healthBonus,
      health: player.maxHealth + rewards.healthBonus,
      attack: player.attack + rewards.attackBonus,
      defense: player.defense + rewards.defenseBonus,
      stats: {
        ...player.stats,
        availablePoints: player.stats.availablePoints + rewards.skillPoints
      }
    };

    setGameState(prev => ({
      ...prev,
      player: updatedPlayer,
      showLevelUp: true,
      lastLevelUpRewards: rewards
    }));
  }, []);

  const gainExp = useCallback((amount: number) => {
    setGameState(prev => {
      const newExp = prev.player.exp + amount;
      const maxExp = calculateExpToNextLevel(prev.player.level);

      if (newExp >= maxExp) {
        const updatedPlayer = {
          ...prev.player,
          level: prev.player.level + 1,
          exp: newExp - maxExp,
          maxExp: calculateExpToNextLevel(prev.player.level + 1)
        };

        handleLevelUp(updatedPlayer);
        return {
          ...prev,
          player: updatedPlayer
        };
      }

      return {
        ...prev,
        player: {
          ...prev.player,
          exp: newExp
        }
      };
    });
  }, [handleLevelUp]);

  const applySkillPointToStat = useCallback((stat: string) => {
    setGameState(prev => ({
      ...prev,
      player: applySkillPoint(prev.player, stat as keyof SkillPoints)
    }));
  }, []);

  // Spawn enemies periodically
  useEffect(() => {
    const spawnInterval = setInterval(() => {
      setGameState(prev => ({
        ...prev,
        enemies: [...prev.enemies, spawnEnemy(prev.player.level)]
      }));
    }, 3000);

    return () => clearInterval(spawnInterval);
  }, []);

  // Handle keyboard controls
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key.toLowerCase()) {
        case 'w':
        case 'arrowup':
          movePlayer('up');
          break;
        case 's':
        case 'arrowdown':
          movePlayer('down');
          break;
        case 'a':
        case 'arrowleft':
          movePlayer('left');
          break;
        case 'd':
        case 'arrowright':
          movePlayer('right');
          break;
        case ' ':
          attackEnemy();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [movePlayer, attackEnemy]);

  return {
    gameState,
    movePlayer,
    attackEnemy,
    gainExp,
    applySkillPointToStat,
    closeLevelUpModal: () => setGameState(prev => ({ ...prev, showLevelUp: false }))
  };
};