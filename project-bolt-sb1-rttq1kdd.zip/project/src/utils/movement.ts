import { Player } from '../types/game';

const MOVEMENT_SPEED = 5;

export const calculateNewPosition = (
  currentPosition: { x: number; y: number },
  direction: 'up' | 'down' | 'left' | 'right'
): { x: number; y: number } => {
  const { x, y } = currentPosition;
  
  switch (direction) {
    case 'up':
      return { x, y: y - MOVEMENT_SPEED };
    case 'down':
      return { x, y: y + MOVEMENT_SPEED };
    case 'left':
      return { x: x - MOVEMENT_SPEED, y };
    case 'right':
      return { x: x + MOVEMENT_SPEED, y };
  }
};

export const isValidPosition = (
  position: { x: number; y: number },
  bounds: { width: number; height: number }
): boolean => {
  return (
    position.x >= 0 &&
    position.x <= bounds.width &&
    position.y >= 0 &&
    position.y <= bounds.height
  );
};