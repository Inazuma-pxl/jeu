import { Enemy } from '../types/game';
import { v4 as uuidv4 } from 'uuid';

const ENEMY_TYPES = [
  {
    name: 'Slime',
    baseHealth: 30,
    baseAttack: 5,
    expValue: 20,
    type: 'monster' as const
  },
  {
    name: 'Goblin',
    baseHealth: 45,
    baseAttack: 8,
    expValue: 35,
    type: 'monster' as const
  },
  {
    name: 'Dark Knight',
    baseHealth: 200,
    baseAttack: 25,
    expValue: 150,
    type: 'boss' as const
  }
];

export const spawnEnemy = (playerLevel: number): Enemy => {
  const isBossSpawn = Math.random() < 0.1; // 10% chance for boss
  const enemyType = isBossSpawn 
    ? ENEMY_TYPES.find(e => e.type === 'boss')! 
    : ENEMY_TYPES.filter(e => e.type === 'monster')[Math.floor(Math.random() * 2)];

  const levelMultiplier = 1 + (playerLevel - 1) * 0.2;
  const health = Math.floor(enemyType.baseHealth * levelMultiplier);
  const attack = Math.floor(enemyType.baseAttack * levelMultiplier);

  // Random position within viewport bounds, with padding
  const padding = 100;
  const x = Math.random() * (window.innerWidth - 2 * padding) + padding;
  const y = Math.random() * (window.innerHeight - 2 * padding) + padding;

  return {
    id: uuidv4(),
    type: enemyType.type,
    name: enemyType.name,
    health,
    maxHealth: health,
    attack,
    position: { x, y },
    sprite: '', // We're using Lucide icons instead of sprites
    isStunned: false,
    expValue: Math.floor(enemyType.expValue * levelMultiplier)
  };
};