import { LevelUpRewards, PlayerStats, SkillPoints } from '../types/leveling';
import { Player } from '../types/game';

export const calculateExpToNextLevel = (level: number): number => {
  return Math.floor(100 * Math.pow(1.5, level - 1));
};

export const calculateLevelUpRewards = (currentLevel: number): LevelUpRewards => {
  const rewards: LevelUpRewards = {
    skillPoints: 5,
    healthBonus: 20 + Math.floor(currentLevel * 1.5),
    attackBonus: 5 + Math.floor(currentLevel * 0.5),
    defenseBonus: 3 + Math.floor(currentLevel * 0.3),
  };

  // Special abilities unlocked at certain levels
  if (currentLevel === 5) {
    rewards.newAbilityUnlocked = 'Whirlwind Strike';
  } else if (currentLevel === 10) {
    rewards.newAbilityUnlocked = 'Thunder Slash';
  } else if (currentLevel === 15) {
    rewards.newAbilityUnlocked = 'Divine Shield';
  }

  return rewards;
};

export const calculateStatsFromSkillPoints = (
  skillPoints: SkillPoints,
  baseStats: Partial<PlayerStats>
): PlayerStats => {
  return {
    ...skillPoints,
    availablePoints: baseStats.availablePoints || 0,
    criticalChance: 5 + skillPoints.agility * 0.5,
    criticalDamage: 150 + skillPoints.strength * 2,
    dodgeChance: skillPoints.agility * 0.3,
    magicResistance: skillPoints.intelligence * 0.5,
  };
};

export const applySkillPoint = (
  player: Player,
  stat: keyof SkillPoints
): Player => {
  if (player.stats.availablePoints <= 0) return player;

  const updatedStats = {
    ...player.stats,
    [stat]: player.stats[stat] + 1,
    availablePoints: player.stats.availablePoints - 1,
  };

  const calculatedStats = calculateStatsFromSkillPoints(updatedStats, updatedStats);

  return {
    ...player,
    stats: calculatedStats,
    maxHealth: player.maxHealth + (stat === 'vitality' ? 10 : 0),
    attack: player.attack + (stat === 'strength' ? 2 : 0),
    defense: player.defense + (stat === 'vitality' ? 1 : 0),
  };
};