import { Player, Enemy } from '../types/game';

const ATTACK_RANGE = 50;
const ATTACK_COOLDOWN = 500; // milliseconds

export const isInRange = (attacker: { position: { x: number; y: number } }, 
                         target: { position: { x: number; y: number } }, 
                         range: number): boolean => {
  const dx = attacker.position.x - target.position.x;
  const dy = attacker.position.y - target.position.y;
  return Math.sqrt(dx * dx + dy * dy) <= range;
};

export const calculateDamage = (attacker: Player | Enemy, defender: Player | Enemy): number => {
  const baseDamage = attacker.attack;
  const defense = 'defense' in defender ? defender.defense : 0;
  const damage = Math.max(1, baseDamage - defense);
  return damage;
};

export const canAttack = (player: Player): boolean => {
  const now = Date.now();
  return !player.isAttacking && (now - player.lastAttackTime) >= ATTACK_COOLDOWN;
};

export const getAttackHitbox = (player: Player): { x: number; y: number; width: number; height: number } => {
  const { x, y } = player.position;
  const hitboxSize = ATTACK_RANGE;

  switch (player.direction) {
    case 'up':
      return { x: x - hitboxSize/2, y: y - hitboxSize, width: hitboxSize, height: hitboxSize };
    case 'down':
      return { x: x - hitboxSize/2, y: y, width: hitboxSize, height: hitboxSize };
    case 'left':
      return { x: x - hitboxSize, y: y - hitboxSize/2, width: hitboxSize, height: hitboxSize };
    case 'right':
      return { x: x, y: y - hitboxSize/2, width: hitboxSize, height: hitboxSize };
  }
};