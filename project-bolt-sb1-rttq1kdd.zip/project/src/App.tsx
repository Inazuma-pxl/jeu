import React from 'react';
import { Player } from './components/Player';
import { Enemy } from './components/Enemy';
import { GameHUD } from './components/GameHUD';
import { AttackEffect } from './components/AttackEffect';
import { LevelUpModal } from './components/LevelUpModal';
import { useGame } from './hooks/useGame';

function App() {
  const { gameState, applySkillPointToStat, closeLevelUpModal } = useGame();

  return (
    <div className="w-full h-screen bg-green-800 overflow-hidden relative">
      <GameHUD player={gameState.player} />
      
      <Player player={gameState.player} />
      
      {gameState.enemies.map(enemy => (
        <Enemy key={enemy.id} enemy={enemy} />
      ))}
      
      {gameState.player.isAttacking && (
        <AttackEffect
          x={gameState.player.position.x}
          y={gameState.player.position.y}
          direction={gameState.player.direction}
        />
      )}
      
      {gameState.showLevelUp && gameState.lastLevelUpRewards && (
        <LevelUpModal
          player={gameState.player}
          rewards={gameState.lastLevelUpRewards}
          onClose={closeLevelUpModal}
          onApplySkillPoint={applySkillPointToStat}
        />
      )}
    </div>
  );
}

export default App;