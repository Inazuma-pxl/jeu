import React from 'react';
import { Sparkles } from 'lucide-react';

interface AttackEffectProps {
  x: number;
  y: number;
  direction: 'up' | 'down' | 'left' | 'right';
}

export const AttackEffect: React.FC<AttackEffectProps> = ({ x, y, direction }) => {
  const getTransform = () => {
    switch (direction) {
      case 'up': return 'translateY(-100%)';
      case 'down': return 'translateY(0)';
      case 'left': return 'translateX(-100%)';
      case 'right': return 'translateX(0)';
    }
  };

  return (
    <div
      className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-attack"
      style={{
        left: `${x}px`,
        top: `${y}px`,
        transform: getTransform()
      }}
    >
      <Sparkles className="w-8 h-8 text-yellow-400" />
    </div>
  );
};