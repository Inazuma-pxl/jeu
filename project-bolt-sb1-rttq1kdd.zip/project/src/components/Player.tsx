import React from 'react';
import { Sword } from 'lucide-react';
import { Player as PlayerType } from '../types/game';

interface PlayerProps {
  player: PlayerType;
}

export const Player: React.FC<PlayerProps> = ({ player }) => {
  return (
    <div 
      className="absolute transform -translate-x-1/2 -translate-y-1/2"
      style={{ 
        left: `${player.position.x}px`, 
        top: `${player.position.y}px`,
        transition: 'all 0.1s ease-out'
      }}
    >
      <Sword className="w-8 h-8 text-green-600" />
      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-20">
        <div className="h-2 bg-gray-300 rounded">
          <div 
            className="h-full bg-red-500 rounded"
            style={{ width: `${(player.health / player.maxHealth) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};