import React from 'react';
import { Trophy, ArrowUp, X } from 'lucide-react';
import { LevelUpRewards } from '../types/leveling';
import { Player } from '../types/game';

interface LevelUpModalProps {
  player: Player;
  rewards: LevelUpRewards;
  onClose: () => void;
  onApplySkillPoint: (stat: string) => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({
  player,
  rewards,
  onClose,
  onApplySkillPoint,
}) => {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <Trophy className="text-yellow-500 w-6 h-6" />
            <h2 className="text-2xl font-bold text-white">Level Up!</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-4 text-white">
          <div className="text-center mb-6">
            <p className="text-xl text-yellow-500">Level {player.level}</p>
            <p className="text-gray-400">You've grown stronger!</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-700 p-3 rounded">
              <p className="text-gray-400">Health Bonus</p>
              <p className="text-green-500">+{rewards.healthBonus}</p>
            </div>
            <div className="bg-gray-700 p-3 rounded">
              <p className="text-gray-400">Attack Bonus</p>
              <p className="text-green-500">+{rewards.attackBonus}</p>
            </div>
          </div>

          {rewards.newAbilityUnlocked && (
            <div className="bg-blue-500/20 p-4 rounded-lg mt-4">
              <h3 className="text-blue-400 font-semibold">New Ability Unlocked!</h3>
              <p className="text-white">{rewards.newAbilityUnlocked}</p>
            </div>
          )}

          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-2">Skill Points Available: {player.stats.availablePoints}</h3>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(player.stats)
                .filter(([key]) => ['strength', 'agility', 'vitality', 'intelligence'].includes(key))
                .map(([stat, value]) => (
                  <button
                    key={stat}
                    onClick={() => onApplySkillPoint(stat)}
                    disabled={player.stats.availablePoints <= 0}
                    className="flex items-center justify-between p-2 bg-gray-700 rounded hover:bg-gray-600 disabled:opacity-50"
                  >
                    <span className="capitalize">{stat}</span>
                    <div className="flex items-center gap-1">
                      <span>{value}</span>
                      <ArrowUp className="w-4 h-4 text-green-500" />
                    </div>
                  </button>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};