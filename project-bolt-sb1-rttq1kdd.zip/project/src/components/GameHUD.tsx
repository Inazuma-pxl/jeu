import React from 'react';
import { Heart, Swords, Trophy } from 'lucide-react';
import { Player } from '../types/game';

interface GameHUDProps {
  player: Player;
}

export const GameHUD: React.FC<GameHUDProps> = ({ player }) => {
  return (
    <div className="fixed top-4 left-4 bg-black/50 p-4 rounded-lg text-white">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Heart className="text-red-500" />
          <span>{player.health}/{player.maxHealth}</span>
        </div>
        <div className="flex items-center gap-2">
          <Trophy className="text-yellow-500" />
          <span>Level {player.level}</span>
        </div>
        <div className="flex items-center gap-2">
          <Swords className="text-blue-500" />
          <span>ATK {player.attack}</span>
        </div>
      </div>
      <div className="mt-2">
        <div className="text-xs">EXP</div>
        <div className="w-full h-2 bg-gray-700 rounded">
          <div
            className="h-full bg-green-500 rounded"
            style={{ width: `${(player.exp / player.maxExp) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};