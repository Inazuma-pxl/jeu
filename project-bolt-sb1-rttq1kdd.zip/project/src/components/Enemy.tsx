import React from 'react';
import { Skull } from 'lucide-react';
import { Enemy as EnemyType } from '../types/game';

interface EnemyProps {
  enemy: EnemyType;
}

export const Enemy: React.FC<EnemyProps> = ({ enemy }) => {
  return (
    <div
      className="absolute transform -translate-x-1/2 -translate-y-1/2"
      style={{
        left: `${enemy.position.x}px`,
        top: `${enemy.position.y}px`,
        transition: 'all 0.1s ease-out'
      }}
    >
      <Skull 
        className={`w-8 h-8 ${enemy.type === 'boss' ? 'text-red-600 w-12 h-12' : 'text-purple-600'}`}
      />
      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-20">
        <div className="h-2 bg-gray-300 rounded">
          <div
            className="h-full bg-red-500 rounded"
            style={{ width: `${(enemy.health / enemy.maxHealth) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};